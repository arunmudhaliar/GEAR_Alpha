// PreCompiled Header

#include <TCHAR.H>
#include <windows.h>
#include <strsafe.h>
#include <d3d9.h>
#include <DXUT.h>
#include <DXUTgui.h>
#include <DXUTcamera.h>
#include <DXUTsettingsdlg.h>
#include <SDKMisc.h>
#include "resource.h"
